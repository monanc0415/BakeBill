﻿$(document).ready(function () {
   
    var table = $('#allItemsCatalogue').DataTable({
        responsive: true,
        //"language": {
        //    "url": ""
        //}
    });

    showItemCatalogue();
    
    $('#allItemsCatalogue tbody').on('click', 'tr', function () {
        $(this).toggleClass('selected');
    });

   

    new $.fn.dataTable.FixedHeader(table);
});

function showItemCatalogue() {
    var db = openDatabase('BakeBill', '1.0', 'The data contains the information about the products and Sales', 2 * 1024 * 1024);
    db.transaction(function (tx) {
        tx.executeSql('SELECT * FROM Products', [], function (tx, results) {

            var len = results.rows.length, i;
          
            for (i = 0; i < len; i++) {
                console.log(results.rows.item(i));
                var Item = results.rows.item(i);
                createRowsInAllItemsCatalogue(Item)
            }

        }, null);
    });


}
function createRowsInAllItemsCatalogue(catalogueItem) {

    $("#allItemsCatalogue tbody").append("<tr role='row'> <td>" + catalogueItem.BrandName + "</td> <td>" + catalogueItem.ProductName + "</td><td>" + catalogueItem.Type + "</td><td>" + catalogueItem.Price + "</td><td>" + catalogueItem.Code + "</td>" +
                "<td>" + catalogueItem.ExpDate + "</td><td><button class='editbtn btn btn-primary' onclick='editItemCatalogue(this)'>Edit</button></td></tr>")

}