﻿var itemArray = [];
var db = openDatabase('BakeBill', '1.0', 'The data contains the information about the products and Sales', 2 * 1024 * 1024);
$(document).ready(function () {



    showItemCatalogue();

    $('#allItemsCatalogue').on('click', 'tr', function () {
        $(this).toggleClass('selected');
    });


    $('.delete').click(function () {
        debugger;
        var selectedLength = $('.selected').length;
        var delItems = [];
        for (var i = 0; i < selectedLength; i++) {
            
            delItems.push($('.selected')["" + i + ""].cells["1"].innerHTML);
           
            var j = 0
            if (db) {
                db.transaction(function (t) {
                    t.executeSql("DELETE FROM Products WHERE ProductName=?", [delItems[j]], function () {
                        alert("Product " + delItems[j] + " has been removed from catalogue");
                        j++;
                        
                        
                    });                   


                });
            } else {
                alert("db not found, your browser does not support web sql!");
            }

        }
        $('.selected').remove();
    });




});

function showItemCatalogue() {

    db.transaction(function (tx) {
        tx.executeSql('SELECT * FROM Products', [], function (tx, results) {

            var len = results.rows.length, i;
            debugger;
            for (i = 0; i < len; i++) {
                console.log(results.rows.item(i));
                var Item = results.rows.item(i);
                var itemObj = Object.values(Item);
                itemArray.push(itemObj);

            }
            createRowsInAllItemsCatalogue(itemArray);

        }, null);
    });


}
function createRowsInAllItemsCatalogue(catalogueItem) {
    $('#allItemsCatalogue').DataTable({
        data: catalogueItem,
        columns: [
            { title: "Brand name" },
            { title: "Product name" },
            { title: "Type" },
            { title: "Price" },
            { title: "Code" },
            { title: "Expiry Date" }

        ],
        responsive: true

    });

    //new $.fn.dataTable.FixedHeader(table);
}

//function createRowsInAllItemsCatalogue(catalogueItem) {

//    $("#allItemsCatalogue tbody").append("<tr role='row'> <td>" + catalogueItem.BrandName + "</td> <td>" + catalogueItem.ProductName + "</td><td>" + catalogueItem.Type + "</td><td>" + catalogueItem.Price + "</td><td>" + catalogueItem.Code + "</td>" +
//                "<td>" + catalogueItem.ExpDate + "</td><td><button class='editbtn btn btn-primary' onclick='editItemCatalogue(this)'>Edit</button></td></tr>")

//}