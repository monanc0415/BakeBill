﻿

var db = openDatabase('BakeBill', '1.0', 'The data contains the information about the products and Sales', 2 * 1024 * 1024);

db.transaction(function (tx) {
    tx.executeSql('CREATE TABLE IF NOT EXISTS Products (BrandName, ProductName, Type, Price, Code ,ExpDate)');
});



function insertInformation(e) {
 
    var BrandName = $('#BrName').val();
    var ProductName = $('#PrName').val();
    var Type = $('#type').val();
    var Price = $('#Price').val();
    var Code = $('#code').val();
    var Expire = $('#Exp').val();

    var db1 = openDatabase('BakeBill', '1.0', 'The data contains the information about the products and Sales', 2 * 1024 * 1024);

    db1.transaction(function (tx) {
        tx.executeSql('INSERT INTO Products (BrandName, ProductName, Type, Price, Code ,ExpDate) VALUES ("' + BrandName + '","' + ProductName + '","' + Type + '","' + Price + '","' + Code + '","' + Expire + '")');
    });

    $("#allItemsCatalogue tbody").append("<tr role='row'> <td>" + BrandName + "</td> <td>" + ProductName + "</td><td>" + Type + "</td><td>" + Price + "</td><td>" + Code + "</td>" +
                    "<td>" + Expire + "</td></tr>")


}

function editItemCatalogue(e)
{
    

   
        debugger;
        var currentTD = $(e).parents('tr').find('td');
        if ($(e).html() == 'Edit') {
            currentTD = $(e).parents('tr').find('td');
            $.each(currentTD, function () {
                $(this).prop('contenteditable', true)
            });
        } else {
            $.each(currentTD, function () {
                $(this).prop('contenteditable', false)
            });
        }

        $(e).html($(e).html() == 'Edit' ? 'Save' : 'Edit')


}

